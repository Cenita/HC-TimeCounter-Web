<template>
    <div>
      <div style="color: #919da4;text-align:center;">
        <p>开发人员简介</p>
        <div>&nbsp</div>
        <p>新计时器系统</p>
        <p>前端，后端，UI设计，爬虫：陈慧涛</p>
        <p>服务器配置：陆仁东</p>
        <p>&nbsp</p>
        <p>旧计时器客户端版本</p>
        <p>客户端：陈潼生，张晓煌</p>
        <p>服务端：邹峰</p>
        <p>UI：刘毓奔</p>
        <p>1.4版本修改：林伟城，何家良</p>
        <p>2.0版本修改：杨容光</p>
        <div>&nbsp</div>
        <p>真诚的感谢所有为工作室奉献过的人</p>
        <p>有你们工作室因此更美好</p>
        <div>&nbsp</div>
        <p>备案号</p>
        <p>粤ICP备14046782号 © 2017 HCLAB since 1999. All rights reserved</p>
        <div>&nbsp</div>
      </div>

    </div>
</template>

<script>
    export default {
        name: "Developer"
    }
</script>

<style scoped>

</style>
