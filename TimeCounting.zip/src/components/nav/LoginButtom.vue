<template>
    <div>
      <a href="" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
      <router-link to="/login" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">person</i></router-link>
    </div>
</template>

<script>
    export default {
        name: "LoginButtom"
    }
</script>

<style scoped>

</style>
